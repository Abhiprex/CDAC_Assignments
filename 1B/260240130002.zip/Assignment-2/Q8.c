#include <stdio.h>

int main(void)
{

int rows = 5; 
for(int i=0 ; i<rows ; i++)
{
for(int j=0 ; j<=i ; j++)
{
printf("%d",i+1);
}
printf("\n");
}


}
